var buffer = new Buffer('Node Intro');

//length of the buffer
console.log("buffer length: " + buffer.length);


