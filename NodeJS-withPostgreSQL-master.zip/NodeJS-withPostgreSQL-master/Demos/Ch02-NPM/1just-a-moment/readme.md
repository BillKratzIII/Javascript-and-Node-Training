This is a sample project that demonstrates using a module.

Open timeExample.js and review the code.

Navigate to a command window for this directory

npm install moment

run using:
 node timeExample.js