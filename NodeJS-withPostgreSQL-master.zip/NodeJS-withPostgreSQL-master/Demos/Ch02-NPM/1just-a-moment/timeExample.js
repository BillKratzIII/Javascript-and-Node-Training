var moment = require('moment');

console.log(moment().format('MM-DD-YYYY'));