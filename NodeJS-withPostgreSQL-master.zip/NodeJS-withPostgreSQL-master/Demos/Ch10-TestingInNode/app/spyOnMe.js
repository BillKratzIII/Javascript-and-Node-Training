module.exports = function(callback) {
    // do important stuff
    callback();
};
