const fs = require("fs");

// Write your code here
